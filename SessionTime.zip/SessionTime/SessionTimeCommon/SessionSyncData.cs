﻿using SessionTime.SessionTimeCommon;
using System;
using System.Net.Http;

namespace SessionTimeCommon
{
    public class SessionSyncData
    {
        private static string serverUrl;
        private static string apiClass;
        private static string dataFilePath;
        private static string logFilePath;

        public static void Initialize(string _serverUrl, string _apiClass, string _dataFilePath, string _logFilePath)
        {
            serverUrl = _serverUrl;
            apiClass = _apiClass;
            dataFilePath = _dataFilePath;
            logFilePath = _logFilePath;

        }

        public static void SyncEmployee()
        {
            try
            {
                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(serverUrl);
                    var response = client.PostAsJsonAsync(apiClass, SessionManager.GetSessionsAll().SessionTrackingParamsList).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        SessionManager.ClearFileData();
                    }
                    else
                    {
                        Utility.Log(logFilePath, "Sync to server error " + DateTime.Now + response.Headers);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Log(logFilePath, "Sync to server error " + DateTime.Now + ex.Message + ex.InnerException);
            }
        }
    }
}



