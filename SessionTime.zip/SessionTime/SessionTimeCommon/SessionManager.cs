﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SessionTime.SessionTimeCommon;
using System.Xml.Linq;
using Cassia;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace SessionTime.SessionTimeCommon
{
    public static class SessionManager
    {
        private static string dataFilePath = null;
        private static string logFilePath = null;

        #region Public methods

        public static void Initialize(string dataFilePath, string logFilePath)
        {
            SessionManager.dataFilePath = dataFilePath;
            SessionManager.logFilePath = logFilePath;
        }

        public static void ClearFileData()
        {
            SessionTracking sessionTracking = null;
            sessionTracking = new SessionTracking();
            sessionTracking.SessionTrackingParamsList = new List<SessionTrackingParams>();
            if (!File.Exists(dataFilePath))
            {
                File.Create(dataFilePath).Close();
            }
            Utility.SerializeObject<SessionTracking>(sessionTracking, dataFilePath);
        }

        public static SessionTracking GetSessionsAll()
        {
           return  Utility.DeSerializeObject<SessionTracking>(dataFilePath);
        }
            public static List<SessionInfo> GetSessions()
        {
            SessionTracking sessionTracking = Utility.DeSerializeObject<SessionTracking>(dataFilePath);
            var sessionTrackingParamsPerServiceRunAndSessionId =
                from o in sessionTracking.SessionTrackingParamsList
                group o by new
                {
                    o.ServiceRunGuid,
                    o.SessionId
                }
                    into g
                    select g;

            var onStartStr = Enum.GetName(typeof(SessionTrackingEvents), SessionTrackingEvents.OnStart);
            var sessionLogonStr = Enum.GetName(typeof(SessionTrackingSupportedReasons), SessionTrackingSupportedReasons.SessionLogon);
            var sessionLogoffStr = Enum.GetName(typeof(SessionTrackingSupportedReasons), SessionTrackingSupportedReasons.SessionLogoff);
            var sessionLockStr = Enum.GetName(typeof(SessionTrackingSupportedReasons), SessionTrackingSupportedReasons.SessionLock);

            List<SessionInfo> sessionInfos = new List<SessionInfo>();
            foreach (var sessionTrackingParams in sessionTrackingParamsPerServiceRunAndSessionId)
            {
                var orderedStps = sessionTrackingParams.OrderBy(o => o.EventDT).ToList();
                if (orderedStps.Count() > 1)
                {
                    var firstStp = orderedStps.First();
                    if (firstStp.Event == onStartStr || firstStp.Reason == sessionLogonStr)
                    {
                        var lastStp = orderedStps.Last();
                        if (lastStp.Reason == sessionLogoffStr)
                        {
                            var si = new SessionInfo()
                                {
                                    SessionId = firstStp.SessionId,
                                    SessionLogonDateTime = firstStp.LogonDT,
                                    SessionLogoffDateTime = lastStp.EventDT,
                                    UserName = firstStp.UserAccount
                                };

                            si.PeriodsInSessionByLockStatus = new List<PeriodInSessionByLockStatus>();
                            var ssbls = new PeriodInSessionByLockStatus()
                            {
                                StartDateTime = firstStp.LogonDT,
                            };
                            si.PeriodsInSessionByLockStatus.Add(ssbls);

                            for (int i = 1; i < orderedStps.Count() - 1; i++)
                            {
                                si.PeriodsInSessionByLockStatus[i - 1].EndDateTime = orderedStps[i].EventDT;
                                si.PeriodsInSessionByLockStatus.Add(
                                    new PeriodInSessionByLockStatus()
                                    {
                                        StartDateTime = orderedStps[i].EventDT,
                                        IsLocked = (orderedStps[i].Reason == sessionLockStr)
                                    });
                            }
                            si.PeriodsInSessionByLockStatus.Last().EndDateTime = lastStp.EventDT;
                            si.PeriodsInSessionByLockStatus.Reverse();
                            sessionInfos.Add(si);
                        }
                    }
                }
            }

            sessionInfos.Reverse();
            return sessionInfos;
        }

        public static void LogSessionData(Guid currentServiceRunGuid, int sessionId, SessionTrackingEvents sessionTrackingEvent, string reason, bool logAllExistingSessions = false)
        {
            using (ITerminalServer server = new TerminalServicesManager().GetLocalServer())
            {
                SessionTracking sessionTracking = null;
                if (!File.Exists(dataFilePath))
                {
                    sessionTracking = new SessionTracking();
                    sessionTracking.SessionTrackingParamsList = new List<SessionTrackingParams>();
                    File.Create(dataFilePath).Close();
                }
                else
                {
                    sessionTracking = Utility.DeSerializeObject<SessionTracking>(dataFilePath);
                }

                server.Open();
                foreach (ITerminalServicesSession session in server.GetSessions().Where(o => o.LoginTime.HasValue))
                {
                    if (logAllExistingSessions || session.SessionId == sessionId)
                    {
                        sessionTracking.SessionTrackingParamsList.Add(
                            new SessionTrackingParams()
                            {
                               ServiceRunGuid = Guid.NewGuid(),
                               SessionId = session.SessionId,
                               LogonDT = session.LoginTime.HasValue ? session.LoginTime.Value : DateTime.MinValue,
                               EventDT = DateTime.Now,
                               UserAccount = (session.UserAccount != null && session.UserAccount.Value != null ? session.UserAccount.Value : String.Empty),
                               Event = Enum.GetName(typeof(SessionTrackingEvents), sessionTrackingEvent),
                               Reason = reason
                            });

                        Utility.SerializeObject<SessionTracking>(sessionTracking, dataFilePath);
                        
                        if (!logAllExistingSessions)
                        {
                            break;
                        }
                    }
                }
                server.Close();
            }
        }

        public static void LogSessionDataWithLoginDate(Guid currentServiceRunGuid, int sessionId, SessionTrackingEvents sessionTrackingEvent, string reason, DateTime loginDate, bool logAllExistingSessions = false)
        {
            using (ITerminalServer server = new TerminalServicesManager().GetLocalServer())
            {
                SessionTracking sessionTracking = null;
                if (!File.Exists(dataFilePath))
                {
                    sessionTracking = new SessionTracking();
                    sessionTracking.SessionTrackingParamsList = new List<SessionTrackingParams>();
                    File.Create(dataFilePath).Close();
                }
                else
                {
                    sessionTracking = Utility.DeSerializeObject<SessionTracking>(dataFilePath);
                }

                server.Open();
                foreach (ITerminalServicesSession session in server.GetSessions().Where(o => o.LoginTime.HasValue))
                {
                    if (logAllExistingSessions || session.SessionId == sessionId)
                    {
                        sessionTracking.SessionTrackingParamsList.Add(
                            new SessionTrackingParams()
                            {
                                ServiceRunGuid = Guid.NewGuid(),
                                SessionId = session.SessionId,
                                LogonDT = loginDate,
                                EventDT = DateTime.Now,
                                UserAccount = (session.UserAccount != null && session.UserAccount.Value != null ? session.UserAccount.Value : String.Empty),
                                Event = Enum.GetName(typeof(SessionTrackingEvents), sessionTrackingEvent),
                                Reason = reason
                            });

                        Utility.SerializeObject<SessionTracking>(sessionTracking, dataFilePath);

                        if (!logAllExistingSessions)
                        {
                            break;
                        }
                    }
                }
                server.Close();
            }
        }

        #endregion

        #region Private methods

        #endregion
    }
}