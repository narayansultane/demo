﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Xml.Linq;
using System.Configuration;
using System.IO;
using System.Diagnostics;
using SessionTime.SessionTimeCommon;

namespace SessionTime.SessionTimeViewer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string dataFilePath = ConfigurationManager.AppSettings["DataFilePath"];
        private string logFilePath = ConfigurationManager.AppSettings["LogFilePath"];

        public MainWindow()
        {
            try
            {
                InitializeComponent();
                SessionManager.Initialize(dataFilePath, logFilePath);
                this.Loaded += MainWindow_Loaded;
            }
            catch (Exception ex)
            {
                Utility.Log(logFilePath, ex.ToString());
            }
        }
    
        #region Event handlers

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadData();
            }
            catch (Exception ex)
            {
                Utility.Log(logFilePath, ex.ToString());
            }
        }

        #endregion

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadData();
            }
            catch (Exception ex)
            {
                Utility.Log(logFilePath, ex.ToString());
            }
        }

        #region Private methods

        private void LoadData()
        {
            if (File.Exists(dataFilePath))
            {
                var sessions = SessionManager.GetSessions();
                if (sessions.Count() > 0)
                {
                    lvSessionMain.ItemsSource = sessions;
                }
            }
        }

        #endregion
    }
}