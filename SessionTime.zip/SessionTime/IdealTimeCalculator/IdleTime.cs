﻿using SessionTime.SessionTimeCommon;
using SessionTimeCommon;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Windows.Threading;

namespace IdealTimeCalculator
{
    public partial class IdleTime : Form
    {
        private DateTime idleStartDateTime = DateTime.Now;
        private string dataFilePath = ConfigurationManager.AppSettings["DataFilePath"];
        private decimal idleTime = Convert.ToDecimal(ConfigurationManager.AppSettings["IdleTime"].ToString());
        private string logFilePath = ConfigurationManager.AppSettings["LogFilePath"];
        private Guid currentServiceRunGuid = Guid.NewGuid();

        public IdleTime()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            SessionManager.Initialize(dataFilePath, logFilePath);
        }

        decimal totaltime = 0;

        LASTINPUTINFO lastInputInf = new LASTINPUTINFO();

        [DllImport("user32.dll")]
        public static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        [StructLayout(LayoutKind.Sequential)]
        public struct LASTINPUTINFO
        {
            [MarshalAs(UnmanagedType.U4)]
            public int cbSize;
            [MarshalAs(UnmanagedType.U4)]
            public int dwTime;
        }

        private void IdelTime_Load(object sender, EventArgs e)
        {
            lblTotalIdealTime.Text = totaltime.ToString();
            DispatcherTimer dt = new DispatcherTimer();
            dt.Tick += dispatcherTimer_Tick;
            dt.Interval = new TimeSpan(0, 0, 1);
            dt.Start();
            this.Hide();
        }

        public void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            lblTotalIdealTime.Text = totaltime.ToString();
            label1.Text = idleStartDateTime.ToString();

            if (totaltime > idleTime*60)
            {
                this.Show();
            }
            if(totaltime==0 && !this.Visible )
            {
                idleStartDateTime = DateTime.Now;
            }
            DisplayTime();
        }

        public int GetLastInputTime()
        {
            int idletime = 0;
            idletime = 0;
            lastInputInf.cbSize = Marshal.SizeOf(lastInputInf);
            lastInputInf.dwTime = 0;

            if (GetLastInputInfo(ref lastInputInf))
            {
                idletime = Environment.TickCount - lastInputInf.dwTime;
            }

            if (idletime != 0)
            {
                return idletime / 1000;
            }
            else
            {
       
                return 0;
            }
        }

        private void DisplayTime()
        {
            totaltime = GetLastInputTime();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            this.Hide();
            //SessionSyncData.Initialize("http://localhost:22389", "api/EmpSync", dataFilePath, logFilePath);
            //SessionSyncData.SyncEmployee();

            idleStartDateTime = DateTime.Now;
            SessionManager.LogSessionDataWithLoginDate(
                    Guid.NewGuid(),
                    -1,
                    SessionTrackingEvents.IdleTime,
                    rtxtReason.Text,
                    idleStartDateTime,
                    true);

        }

        private void IdleTime_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel=true;
        }
    }
}
